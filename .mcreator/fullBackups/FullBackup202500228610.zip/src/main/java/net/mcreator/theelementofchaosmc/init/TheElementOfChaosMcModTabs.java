/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.theelementofchaosmc.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.theelementofchaosmc.TheElementOfChaosMcMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TheElementOfChaosMcModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TheElementOfChaosMcMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(TheElementOfChaosMcModItems.RED_GEM.get());
			tabData.accept(TheElementOfChaosMcModItems.ADVENTURERS_LEATHER_ARMOR_CHESTPLATE.get());
			tabData.accept(TheElementOfChaosMcModItems.ADVENTURERS_LEATHER_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(TheElementOfChaosMcModItems.SHAPENED_OBSIDIAN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(TheElementOfChaosMcModItems.OBSIDIAN_SWORD.get());
			tabData.accept(TheElementOfChaosMcModItems.BROKEN_RED_GEM.get());
		}
	}
}