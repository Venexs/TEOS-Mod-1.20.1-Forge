/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.theelementofchaosmc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.theelementofchaosmc.block.ManaInfusedStoneBlock;
import net.mcreator.theelementofchaosmc.TheElementOfChaosMcMod;

public class TheElementOfChaosMcModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TheElementOfChaosMcMod.MODID);
	public static final RegistryObject<Block> MANA_INFUSED_STONE = REGISTRY.register("mana_infused_stone", () -> new ManaInfusedStoneBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}