package net.mcreator.theelementofchaosmc.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.theelementofchaosmc.network.TheElementOfChaosMcModVariables;

public class ElementPickConfirmProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TheElementOfChaosMcModVariables.PlayerVariables())).element_pick;
			entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.magic_type = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if (entity instanceof ServerPlayer _player) {
			Advancement _adv = _player.server.getAdvancements().getAdvancement(ResourceLocation.parse("the_element_of_chaos_mc:magic_selected"));
			AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
			if (!_ap.isDone()) {
				for (String criteria : _ap.getRemainingCriteria())
					_player.getAdvancements().award(_adv, criteria);
			}
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}
}