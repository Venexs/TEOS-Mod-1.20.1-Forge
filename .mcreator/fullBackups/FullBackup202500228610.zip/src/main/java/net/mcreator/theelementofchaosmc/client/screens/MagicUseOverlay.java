package net.mcreator.theelementofchaosmc.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Minecraft;

import net.mcreator.theelementofchaosmc.procedures.IsElementFireProcedure;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class MagicUseOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexShader);
		RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		RenderSystem.setShaderColor(1, 1, 1, 1);
		if (true) {
			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/textspace.png"), w - 43, h - 69, 0, 0, 8, 8, 8, 8);

			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/textspace.png"), w - 43, h - 52, 0, 0, 8, 8, 8, 8);

			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/textspace.png"), w - 43, h - 35, 0, 0, 8, 8, 8, 8);

			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/inventory.png"), w - 34, h - 69, 0, 0, 16, 16, 16, 16);

			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/inventory.png"), w - 34, h - 52, 0, 0, 16, 16, 16, 16);

			event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/inventory.png"), w - 34, h - 35, 0, 0, 16, 16, 16, 16);

			if (IsElementFireProcedure.execute(entity)) {
				event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/fire_laser.png"), w - 32, h - 33, 0, 0, 12, 12, 12, 12);
			}
			if (IsElementFireProcedure.execute(entity)) {
				event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/fire_rock.png"), w - 32, h - 67, 0, 0, 12, 12, 12, 12);
			}
			if (IsElementFireProcedure.execute(entity)) {
				event.getGuiGraphics().blit(ResourceLocation.parse("the_element_of_chaos_mc:textures/screens/fire_wall.png"), w - 32, h - 50, 0, 0, 12, 12, 12, 12);
			}
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.the_element_of_chaos_mc.magic_use.label_x"), w - 42, h - 69, -16777216, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.the_element_of_chaos_mc.magic_use.label_z"), w - 42, h - 52, -16777216, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.the_element_of_chaos_mc.magic_use.label_c"), w - 42, h - 35, -16777216, false);
		}
		RenderSystem.depthMask(true);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}