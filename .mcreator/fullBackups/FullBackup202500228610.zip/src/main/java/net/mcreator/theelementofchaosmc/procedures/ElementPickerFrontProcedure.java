package net.mcreator.theelementofchaosmc.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.theelementofchaosmc.network.TheElementOfChaosMcModVariables;

public class ElementPickerFrontProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TheElementOfChaosMcModVariables.PlayerVariables())).element_pick > 2) {
			{
				double _setval = 0;
				entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.element_pick = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		{
			double _setval = (entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TheElementOfChaosMcModVariables.PlayerVariables())).element_pick + 1;
			entity.getCapability(TheElementOfChaosMcModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.element_pick = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}