/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.theelementofchaosmc.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.theelementofchaosmc.item.ShapenedObsidianItem;
import net.mcreator.theelementofchaosmc.item.RedGemItem;
import net.mcreator.theelementofchaosmc.item.ObsidianSwordItem;
import net.mcreator.theelementofchaosmc.item.ManaSoulItem;
import net.mcreator.theelementofchaosmc.item.BrokenRedGemItem;
import net.mcreator.theelementofchaosmc.item.AdventurersLeatherArmorItem;
import net.mcreator.theelementofchaosmc.TheElementOfChaosMcMod;

public class TheElementOfChaosMcModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TheElementOfChaosMcMod.MODID);
	public static final RegistryObject<Item> RED_GEM = REGISTRY.register("red_gem", () -> new RedGemItem());
	public static final RegistryObject<Item> SHAPENED_OBSIDIAN = REGISTRY.register("shapened_obsidian", () -> new ShapenedObsidianItem());
	public static final RegistryObject<Item> OBSIDIAN_SWORD = REGISTRY.register("obsidian_sword", () -> new ObsidianSwordItem());
	public static final RegistryObject<Item> ADVENTURERS_LEATHER_ARMOR_CHESTPLATE = REGISTRY.register("adventurers_leather_armor_chestplate", () -> new AdventurersLeatherArmorItem.Chestplate());
	public static final RegistryObject<Item> ADVENTURERS_LEATHER_ARMOR_BOOTS = REGISTRY.register("adventurers_leather_armor_boots", () -> new AdventurersLeatherArmorItem.Boots());
	public static final RegistryObject<Item> BROKEN_RED_GEM = REGISTRY.register("broken_red_gem", () -> new BrokenRedGemItem());
	public static final RegistryObject<Item> MANA_SOUL = REGISTRY.register("mana_soul", () -> new ManaSoulItem());
	public static final RegistryObject<Item> MANA_INFUSED_STONE = block(TheElementOfChaosMcModBlocks.MANA_INFUSED_STONE, new Item.Properties().rarity(Rarity.RARE));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}